<?php


/*
Plugin Name: Placester Test
Plugin URI:  http://URI_Of_Page_Describing_Plugin_and_Updates
Description: Generates oEmbed-compliant listings pulled from the Placester API.
Version:     1.0
Author:      Ben Hopps
Author URI:  https://benhopps.com
License:     GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Domain Path: /languages
Text Domain: placestertest
*/

function placestertest_activate() {

	// Define listings function and call it once on load.
	$content =
	'<script type="text/javascript">function getListings(page){jQuery.ajax({url: "'.admin_url('admin-ajax.php').'",data: {"action": "get_listings", "page" : page }, success:function(data) { jQuery("#content .entry-content p").html(data); }, error: function(errorThrown){ console.log(errorThrown); } });}getListings("url");</script>';


	// Create post object
	$post = array(
	'post_type'	=> 'page',
	'post_title'    => 'listings',
	'post_content'  => $content,
	'post_status'   => 'publish',
	'post_author'   => 1,
	'post_category' => array(8,39),
	);

	// Insert the post into the database
	wp_insert_post( $post );
}

register_activation_hook( __FILE__, 'placestertest_activate' );

# Not deleting posts on 'deactivate' to save time. testing with mysql DELETE

add_action( 'wp_ajax_get_listings', 'placestertest_ajax_get_listings' );

function placestertest_ajax_get_listings() {
	// Handle request then generate response using WP_Ajax_Response

	// Yes, hardcoding is bad. In real life, these would be an admin options.

	$api_key = '3eb444f8869cb88bbc349586573aabbb84a316d7';
	$url = 'http://api.placester.com/api/v2.1/listings.json?api_key='.$api_key;

	$curlcall = curl_init();
	curl_setopt($curlcall, CURLOPT_URL, $url);
	curl_setopt($curlcall, CURLOPT_RETURNTRANSFER, true);
	 
	$curlout = curl_exec($curlcall);
	$listings = json_decode($curlout, true);

	// If I was trying harder, I'd use an error handler here

	if( $listings['count'] < 1 ) { die('Error: No listings found.'); }


	// This html belongs in a page template I imagine.

	echo '<div id="placester-page"><span>Page:</span>';

	$num_pages = ($listings['count'] / 15);
	for($i=1;$i<$num_pages;$i++) {

		// I know, inline CSS is bad.
		echo '<span style="cursor:pointer" onclick="getListings('.$i.')">'.$i.'</span>';
	}
	echo '</div><div id="placester-listings">';

	$p = $_REQUEST['page'];

	if($p == 'url') {	
		$url = explode('/', $_SERVER['HTTP_REFERER']);
		$p = 1;
		for($i=0;$i<sizeof($url);$i++) {
			if($url[$i] == 'listings') {
				$p = $url[($i +1)].'<br>';
			}
		}
	}

	// Just doing simple error checking assuming there will
	// always be 45 listings returned by the API.

	if($p < 1) {
		$p = 1;
	}
	if($p > 3) {
		$p = 3;
	}

	$first_listing = ($p - 1) * 15;
	$last_listing = $first_listing + 15;

	for($i=$first_listing;$i<$last_listing;$i++) {
		echo '<div class="placester-address">';
		echo '<span>'.$listings['listings'][$i]['location']['address'].'</span>';
		echo '<span>'.$listings['listings'][$i]['location']['locality'].'</span>';
		echo '<span>'.$listings['listings'][$i]['location']['region'].'</span>';
		echo '<span>'.$listings['listings'][$i]['location']['postal'].'</span>';
		echo '<span>'.$listings['listings'][$i]['location']['country'].'</span>';
		echo '</div>';

		// The API returns 0 for some listings. If I was trying harder, 
		// I'd add an error/notification.

		echo '<div class="placester-price">Price: $'.$listings['listings'][$i]['cur_data']['price'].'</div>';

		// I could add more data from the API response, but this is a good
		// proof of concept.
	}

	// I'm not sure why it's printing a '0' at the bottom
	echo "</div>";
}
?>
